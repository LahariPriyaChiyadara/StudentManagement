package StudentManagement;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table
public class Enrollment{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	 private int enrollmentid;

    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    @ManyToOne
    @JoinColumn(name = "student_id")
    private Student student;

    @Temporal(TemporalType.DATE)
    @Column(name = "enrollment_date")
    private Date enrollmentDate;

	private int enrollmentId;

	 

	  
	    public Enrollment(int enrollmentId, Student student, Course course, Date enrollmentDate) {
	        this.enrollmentId = enrollmentId;
	        this.student = student;
	        this.course = course;
	        this.enrollmentDate = enrollmentDate;
	    }

	    // Getters and setters for each attribute

	    public int getEnrollmentId() {
	        return enrollmentId;
	    }

	    public void setEnrollmentId(int enrollmentId) {
	        this.enrollmentId = enrollmentId;
	    }

	    public Student getStudent() {
	        return student;
	    }

	    public void setStudent(Student student) {
	        this.student = student;
	    }

	    public Course getCourse() {
	        return course;
	    }

	    public void setCourse(Course course) {
	        this.course = course;
	    }

	    public Date getEnrollmentDate() {
	        return enrollmentDate;
	    }

	    public void setEnrollmentDate(Date enrollmentDate) {
	        this.enrollmentDate = enrollmentDate;
	    }

	    // toString() method to represent Enrollment object as a string

	    @Override
		public String toString() {
			return "Enrollment [enrollmentid=" + enrollmentid + ", course=" + course + ", student=" + student
					+ ", enrollmentDate=" + enrollmentDate + ", enrollmentId=" + enrollmentId + "]";
		}


}
