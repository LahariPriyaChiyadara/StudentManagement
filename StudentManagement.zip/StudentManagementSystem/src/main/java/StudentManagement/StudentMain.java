package StudentManagement;

import java.util.Date;

import java.util.List;

public class StudentMain {

	public static void main(String[] args) {
		
		        StudentDao sdao = new StudentDao();

		        // Add a student
		        Student s1 = new Student("Lahari_Priya", "laharipriya1802@gmail,com");
		        Student s2 = new Student("Krishna", "krishna234@gmail.com");
		        Student s3 = new Student("Mahesh", "mahesh35@gmail.com");
		        sdao.addStudent(s1);
		        sdao.addStudent(s2);
		        sdao.addStudent(s3);
		        System.out.println("Student added successfully.");

		        // Update a student
		        Student studentToUpdate = sdao.getStudentById(1); // Assuming student with ID 1 exists
		        if (studentToUpdate != null) {
		            studentToUpdate.setName("Jaya");
		            studentToUpdate.setEmail("jaya4464@gmail.com");
		            sdao.updateStudent(studentToUpdate);
		            System.out.println("Student updated successfully.");
		        } else {
		            System.out.println("Student not found.");
		        }

		        // Delete a student
		        Student studentToDelete = sdao.getStudentById(2); // Assuming student with ID 2 exists
		        if (studentToDelete != null) {
		            sdao.deleteStudent(studentToDelete);
		            System.out.println("Student deleted successfully.");
		        } else {
		            System.out.println("Student not found.");
		        }

		        // Get a student by ID
		        int studentId = 3; // Assuming student with ID 3 exists
		        Student studentById = sdao.getStudentById(studentId);
		        if (studentById != null) {
		            System.out.println("Student found:");
		            System.out.println("ID: " + studentById.getId());
		            System.out.println("Name: " + studentById.getName());
		            System.out.println("Email: " + studentById.getEmail());
		        } else {
		            System.out.println("Student not found.");
		        }

                // Create a CourseDAO instance
                CourseDAO courseDAO = new CourseDAO();

                // Creating a new course
                Course c1 = new Course("2001", "Java Programming", 3, "John Doe");
                Course c2 = new Course("2002", "Database Management", 4, "Jane Smith");

                // Adding courses to the database
                courseDAO.addCourse(c1);
                courseDAO.addCourse(c2);

                // Getting course by ID
                Course retrievedCourse = courseDAO.getCourseById("C001");
                if (retrievedCourse != null) {
                    System.out.println("Retrieved Course: " + retrievedCourse);
                } else {
                    System.out.println("Course not found!");
                }

                // Deleting a course
                courseDAO.deleteCourse("2002");

                // Getting all courses
                List<Course> allCourses = courseDAO.getAllCourses();
                System.out.println("All Courses:");
                for (Course course : allCourses) {
                    System.out.println(course);
                }

                // Close CourseDAO
                courseDAO.close();
                
                // Create an EnrollmentDAO object
                EnrollmentDAO edao = new EnrollmentDAO();

                // Enroll students in courses
                Enrollment e1 = new Enrollment(1, s1, c1, new Date());
                Enrollment e2 = new Enrollment(2, s1, c2, new Date());
                Enrollment e3 = new Enrollment(3, s2, c1, new Date());

                // Add enrollments to the EnrollmentDAO
                edao.addEnrollment(e1);
                edao.addEnrollment(e2);
                edao.addEnrollment(e3);

                // Retrieve and display all enrollments
                System.out.println("All Enrollments:");
                for (Enrollment enrollment : edao.getAllEnrollments()) {
                    System.out.println(enrollment);
                }

                // Retrieve and display enrollments for a particular student (e.g., student1)
                System.out.println("\nEnrollments for Student: " + s1.getName());
                for (Enrollment enrollment : edao.getEnrollmentsByStudent(s1)) {
                    System.out.println(enrollment);
                }

                // Retrieve and display enrollments for a particular course (e.g., course1)
                System.out.println("\nEnrollments for Course: " + c1.getCourseName());
                for (Enrollment enrollment : edao.getEnrollmentsByCourse(c1)) {
                    System.out.println(enrollment);
                }
                
		           
		    }

}
