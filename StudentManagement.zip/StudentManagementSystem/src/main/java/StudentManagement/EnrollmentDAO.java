package StudentManagement;

import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAO {
	    private List<Enrollment> enrollments;

	    public EnrollmentDAO() {
	        this.enrollments = new ArrayList<>();
	    }

	    // Method to add an enrollment to the list
	    public void addEnrollment(Enrollment enrollment) {
	        enrollments.add(enrollment);
	    }

	    // Method to retrieve all enrollments
	    public List<Enrollment> getAllEnrollments() {
	        return enrollments;
	    }

	    // Method to retrieve all enrollments for a particular student
	    public List<Enrollment> getEnrollmentsByStudent(Student student) {
	        List<Enrollment> studentEnrollments = new ArrayList<>();
	        for (Enrollment enrollment : enrollments) {
	            if (enrollment.getStudent().equals(student)) {
	                studentEnrollments.add(enrollment);
	            }
	        }
	        return studentEnrollments;
	    }

	    // Method to retrieve all enrollments for a particular course
	    public List<Enrollment> getEnrollmentsByCourse(Course course) {
	        List<Enrollment> courseEnrollments = new ArrayList<>();
	        for (Enrollment enrollment : enrollments) {
	            if (enrollment.getCourse().equals(course)) {
	                courseEnrollments.add(enrollment);
	            }
	        }
	        return courseEnrollments;
	    }


}
