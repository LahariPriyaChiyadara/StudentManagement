package StudentManagement;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Courses")
public class Course<invalid> {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
    public Long courseCode;
	@Column(name="CourseName")
    public String courseName;
	@Column(name="creditTime")
    public int creditHours;
	@Column(name="InstructorName")
    public String instructor;

    public Course(Long courseCode, String courseName, int creditHours, String instructor) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.creditHours = creditHours;
        this.instructor = instructor;
    }

    public Course(String string, String courseName2, int creditHours2, String instructor2) {
		
	}

	// Getters and setters for each attribute
	public Long getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(Long courseCode) {
        this.courseCode = courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getCreditHours() {
        return creditHours;
    }

    public void setCreditHours(int invalid) {
        this.creditHours = invalid;
    }

    public String getInstructor() {
        return instructor;
    }

    public Course() {
		super();
		
	}

	public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    // toString() method to represent Course object as a string

    @Override
	public String toString() {
		return "Course [courseCode=" + courseCode + ", courseName=" + courseName + ", creditHours=" + creditHours
				+ ", instructor=" + instructor + "]";
	}

}
