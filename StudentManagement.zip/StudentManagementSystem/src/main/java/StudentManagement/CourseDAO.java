package StudentManagement;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CourseDAO {
   
	    private SessionFactory sessionFactory;

	    public CourseDAO() {
	        // Initialize Hibernate session factory
	        sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	    }

	    // Method to add a course to the database
	    public void addCourse(Course course) {
	        Session session = sessionFactory.openSession();
	        Transaction transaction = session.beginTransaction();
	        session.save(course);
	        transaction.commit();
	        session.close();
	    }

	    // Method to retrieve all courses from the database
	    public List<Course> getAllCourses() {
	        Session session = sessionFactory.openSession();
	        List<Course> courses = session.createQuery("FROM Course", Course.class).list();
	        session.close();
	        return courses;
	    }
        //Method to get a course by its ID
			public Course getCourseById(Long courseId) {
	       
			Session session = sessionFactory.openSession();
	        Course course = session.get(Course.class, courseId);
	        session.close();
	        return course;
		}
		// Method to delete a course by its ID
		public void deleteCourse(Long courseId) {
		    Session session = sessionFactory.openSession();
		    Transaction transaction = session.beginTransaction();
		    Course course = session.get(Course.class, courseId); // Use courseId instead of course
		    if (course != null) {
		        session.delete(course);
		    }
		    transaction.commit();
		    session.close();
		}

		// Close SessionFactory
		public void close() {
    	   sessionFactory.close();
		}

		public Course getCourseById(String string) {
			
			return null;
		}

		public void deleteCourse(String string) {
			// TODO Auto-generated method stub
			
		}
			
}
	
    