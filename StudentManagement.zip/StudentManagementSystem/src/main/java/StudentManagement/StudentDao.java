package StudentManagement;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentDao {
	

	    private SessionFactory factory;

	    public StudentDao() {
	        Configuration configuration = new Configuration().configure();
	        factory = configuration.buildSessionFactory();
	    }

	    public void addStudent(Student student) {
	        Transaction transaction = null;
	        try (Session session = factory.openSession()) {
	            transaction = session.beginTransaction();
	            session.save(student);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
	    }

	    public void updateStudent(Student student) {
	        Transaction transaction = null;
	        try (Session session = factory.openSession()) {
	            transaction = session.beginTransaction();
	            session.update(student);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
	    }

	    public void deleteStudent(Student student) {
	        Transaction transaction = null;
	        try (Session session = factory.openSession()) {
	            transaction = session.beginTransaction();
	            session.delete(student);
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            e.printStackTrace();
	        }
	    }

	    public Student getStudentById(int id) {
	        try (Session session = factory.openSession()) {
	            return session.get(Student.class, id);
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }

}
